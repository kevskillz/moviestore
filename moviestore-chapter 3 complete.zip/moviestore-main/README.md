# Welcome to our CS2340 Project 1 - Movies Store
Armin 1 Team  

## Group Members
Shrey Agarwal  
Kevin Lobo  
Keshav Chinnakotla  
Shiv Patel  
Aarav Mehta  
Sathwik Doddi  